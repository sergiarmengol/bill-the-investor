# bill-the-investor

Application to be able to compare stock prices over different markets from anywhere in the world.
-> Create company profiles in the system
-> Add company stock and corresponding price to an exchange market.
-> Display reports of the stock/companies/exchanges
  - An overview of all companies and what stock they have on which markets
  - An overview of all stock exchanges and what company’s stock is traded there
  - For each company stock to able to see the currently highest trade value and corresponding exchange market.
  
## IMPORTANT

1. To Set up the Database: localhost/setupdatabase
2. The Database has already some examples.

